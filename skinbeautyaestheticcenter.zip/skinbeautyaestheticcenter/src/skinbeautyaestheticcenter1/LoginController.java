package skinbeautyaestheticcenter1;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author USER
 */
public class LoginController implements Initializable {

    @FXML
    private PasswordField password;
    @FXML
    private Button loginBtn;
    private static final String correctPassword = "admin123";
    private int attempts = 0;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

    
    @FXML
    private void clickLoginBtn(ActionEvent event) throws IOException {
        validateLogin();
    }

    void validateLogin() throws IOException {
        if (correctPassword.equals(password.getText())) {
            showMainPage();
        } else {
            attempts++;
            if (attempts >= 3) {
                showAlert("Maximum attempts reached. Exiting application.");
                System.exit(0);
            } else {
                showAlert("Incorrect password. Attempts left: " + (3 - attempts));
                password.clear();
            }
        }
    }
    public static void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    private void showMainPage() throws IOException{
        Parent root = FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        Stage newStage = new Stage();
        Scene scene = new Scene(root);
        newStage.setTitle("My World Home Service");
        newStage.setScene(scene);
        newStage.show();
        ((Stage) loginBtn.getScene().getWindow()).close();
        
    }
}  