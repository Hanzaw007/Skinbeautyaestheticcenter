package skinbeautyaestheticcenter1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.Scanner;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;

public class MainPageController implements Initializable {

    // File to store customer records
    File file = new File("customers.txt");

    // List to hold cost records temporarily before writing to file
    ArrayList<String> TotalCost = new ArrayList<>();

    // Variables to store customer input
    int customerID;
    String customerName;

    // JavaFX UI elements
    @FXML private TextField name;
    @FXML private TextField id;
    @FXML private ListView<String> treatments;
    @FXML private ToggleGroup membership;
    @FXML private Button submit;
    @FXML private TextArea selectedTreatments;
    @FXML private Label totalCostBefore;
    @FXML private Label totalCostAfter;
    @FXML private Label totaldiscount;
    @FXML private Button confirm;
    @FXML private Label nameoutput;
    @FXML private Label numtreatments;
    @FXML private TextField membership1;

    // Treatment names and their corresponding prices
    public static final String[] treatmentList = {
        "Chemical Peel - per session : £175.00",
        "Microneedling - per session : £275.00",
        "PRP Therapy - per session : £100.00",
        "HIFU Treatment - per session : £400.00",
        "Hair Treatment - per session : £100.00",
        "Manicure - per session : £20.00",
        "Pedicure - per session: £25.00"
    };

    public static final int[] priceList = {175, 275, 100, 400, 100, 20, 25};

    // Initialize method to load treatments into the ListView
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        ObservableList<String> items = FXCollections.observableArrayList(treatmentList);
        treatments.setItems(items);  // Populate treatment list
        treatments.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE); // Allow multi-selection
    }

    // Handle submission of selected treatments
    @FXML
    private void submitTreatments(MouseEvent event) throws FileNotFoundException {
        // Validate required input fields
        if (id.getText().trim().isEmpty() || name.getText().trim().isEmpty()) {
            LoginController.showAlert("Please enter your ID and Name.");
            return;
        }

        try {
            customerID = Integer.parseInt(id.getText().trim());
        } catch (NumberFormatException e) {
            LoginController.showAlert("ID must be a number.");
            return;
        }

        customerName = name.getText().trim();

        // Get indices of selected treatments
        ObservableList<Integer> selectedIndices = treatments.getSelectionModel().getSelectedIndices();
        int[] indexTreatments = selectedIndices.stream().mapToInt(i -> i).toArray();

        if (indexTreatments.length == 0) {
            LoginController.showAlert("Please select at least one treatment.");
            return;
        }

        // Parse membership duration
        int duration;
        try {
            duration = Integer.parseInt(membership1.getText().trim());
        } catch (NumberFormatException e) {
            LoginController.showAlert("Membership must be a number.");
            return;
        }

        try {
            // Get customer's previous cost from file
            int previousCost = totalPreviousCost();

            // Create new client object with current input
            Client client = new Client(customerID, customerName, indexTreatments, duration, previousCost);

            // Perform discount and cost calculation
            client.calculateCost();

            // Display the results on screen
            displayClientInfo(client);

            // Update client record list
            recordlist(client);

        } catch (Exception e) {
            LoginController.showAlert("Error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    // Display client's cost details on the UI
    private void displayClientInfo(Client c) {
        StringBuilder sb = new StringBuilder();
        for (int i : c.getSelectedTreatments()) {
            sb.append(String.format("| %-35s | £%3d |\n", treatmentList[i], priceList[i]));
        }
        selectedTreatments.setText(sb.toString());  // Show selected treatments with prices
        totalCostBefore.setText("£" + c.getTotalCost());
        totalCostAfter.setText("£" + c.getTotalCostDiscount());
        totaldiscount.setText("£" + c.getDiscounts());
        nameoutput.setText(customerName);
        numtreatments.setText(String.valueOf(c.getNumberOfTreatments()));
    }

    // Read file and return total previous cost of the customer
    private int totalPreviousCost() throws FileNotFoundException {
        int total = 0;
        if (file.exists()) {
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                String[] parts = line.split(":");
                // Match based on ID
                if (parts.length >= 3 && Integer.parseInt(parts[0].trim()) == customerID) {
                    String[] costs = parts[2].trim().split(" ");
                    for (String cost : costs) {
                        try {
                            total += Integer.parseInt(cost.trim());
                        } catch (NumberFormatException ignored) {}
                    }
                }
            }
            reader.close();
        }
        return total;
    }

    // Confirm and write client record data to the file
    @FXML
    private void confirmrecord(MouseEvent event) throws FileNotFoundException {
        PrintWriter writer = new PrintWriter(file);
        for (String record : TotalCost) {
            writer.println(record);
        }
        writer.close();
        System.out.println("Records written to file.");
        Clear();  // Clear UI fields
    }

    // Prepare the updated record list (overwrite or append to existing)
    void recordlist(Client c) throws FileNotFoundException {
        TotalCost.clear();
        boolean found = false;
        int discount = c.getTotalCostDiscount();

        if (file.exists()) {
            Scanner reader = new Scanner(file);
            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                String[] parts = line.split(":");

                if (parts.length >= 3) {
                    int id = Integer.parseInt(parts[0].trim());
                    String name = parts[1].trim();

                    // If the client already exists, update their line
                    if (id == customerID && name.equalsIgnoreCase(customerName)) {
                        found = true;
                        String updated = parts[2].trim() + " " + discount;
                        TotalCost.add(customerID + ":" + customerName + ":" + updated);
                    } else {
                        TotalCost.add(line);  // Keep existing line unchanged
                    }
                } else {
                    TotalCost.add(line);  // Add invalid lines as-is
                }
            }
            reader.close();
        }

        // If new client, add new record line
        if (!found) {
            TotalCost.add(customerID + ":" + customerName + ":" + discount);
        }
    }

    // Reset all input fields and outputs
    void Clear() {
        treatments.getSelectionModel().clearSelection();
        id.clear();
        name.clear();
        membership1.clear();
        selectedTreatments.clear();
        totalCostBefore.setText("£0");
        totalCostAfter.setText("£0");
        totaldiscount.setText("£0");
        nameoutput.setText("Name: ");
        numtreatments.setText("Number of selected Treatments: ");
    }
}
