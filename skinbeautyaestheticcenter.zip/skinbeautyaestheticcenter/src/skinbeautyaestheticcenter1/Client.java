package skinbeautyaestheticcenter1;

public class Client {

    private int ID;
    private String name;
    private int[] selectedTreatments;
    private boolean member;
    private int totalCost = 0;
    private int totalCostDiscount;
    private int duration;
    private int previousCost;
    private int discounts;
    private int totalRecords;

    public Client(int id, String name, int[] selectedTreatments, int duration, int previousCost) {
        this.ID = id;
        this.name = name;
        this.selectedTreatments = selectedTreatments;
        this.duration = duration;
        this.previousCost = previousCost;
    }

    public void calculateCost() {
        System.out.println("Calculating");
        for (int index : selectedTreatments) {
            totalCost += MainPageController.priceList[index];
        }

        totalRecords = totalCost + previousCost;

        double percent = 0;
        if (totalRecords > 1500) {
            percent = 15;
        } else if (totalRecords > 1000) {
            percent = 10;
        } else if (totalRecords > 500) {
            percent = 5;
        }

        if (duration >= 12) {
            percent += 5;
        }

        discounts = (int) (totalCost * (percent / 100));
        totalCostDiscount = totalCost - discounts;
    }

    public int getTotalCost() {
        return totalCost;
    }

    public int getTotalCostDiscount() {
        return totalCostDiscount;
    }

    public int getDiscounts() {
        return discounts;
    }

    public int getNumberOfTreatments() {
        return selectedTreatments.length;
    }

    public int[] getSelectedTreatments() {
        return selectedTreatments;
    }
    public int getid(){
        return ID;
    }
   
    public String getname(){
        return name;
    }

}

   